package com.example.radhika_q5;

import android.content.Context;
import android.net.Uri;
import android.provider.DocumentsContract;

public class FileUtil {
    public static String getFullPathFromTreeUri(Uri uri, Context context) {
        final String docId = DocumentsContract.getTreeDocumentId(uri);
        final String[] split = docId.split(":");
        final String type = split[0];
        String path = "";

        if ("primary".equalsIgnoreCase(type)) {
            path = "/storage/emulated/0/" + split[1];
        }

        return path;
    }
}
