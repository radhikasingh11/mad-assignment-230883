package com.example.radhika_q5;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import java.io.File;
import java.util.ArrayList;

public class ImageAdapter extends BaseAdapter {
    Context context;
    ArrayList<File> images;

    public ImageAdapter(Context context, ArrayList<File> images) {
        this.context = context;
        this.images = images;
    }

    @Override
    public int getCount() { return images.size(); }

    @Override
    public Object getItem(int i) { return images.get(i); }

    @Override
    public long getItemId(int i) { return i; }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        ImageView imageView = new ImageView(context);
        imageView.setImageBitmap(BitmapFactory.decodeFile(images.get(position).getPath()));
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setLayoutParams(new ViewGroup.LayoutParams(300, 300));

        imageView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ImageDetailActivity.class);
            intent.putExtra("imagePath", images.get(position).getPath());
            context.startActivity(intent);
        });

        return imageView;
    }
}
