package com.example.radhika_q5;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ImageDetailActivity extends AppCompatActivity {

    ImageView imageView;
    TextView detailsText;
    Button btnDelete;
    String imagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_detail);

        imageView = findViewById(R.id.image_view);
        detailsText = findViewById(R.id.text_details);
        btnDelete = findViewById(R.id.btn_delete);

        imagePath = getIntent().getStringExtra("imagePath");
        File imageFile = new File(imagePath);

        imageView.setImageBitmap(BitmapFactory.decodeFile(imagePath));
        detailsText.setText("Name: " + imageFile.getName() +
                "\nPath: " + imagePath +
                "\nSize: " + imageFile.length() / 1024 + " KB" +
                "\nDate: " + new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date(imageFile.lastModified())));

        btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Image")
                    .setMessage("Are you sure you want to delete this image?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (imageFile.delete()) {
                            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                            finish(); // go back
                        } else {
                            Toast.makeText(this, "Failed to delete", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
    }
}
